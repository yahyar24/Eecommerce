<?php $__env->startSection('content'); ?>

<?php echo $__env->make('admin.includes.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="panel panel-default">
      
      <div class="panel-heading">
      
      update product
      </div>
      
      <div class="panel-body">
      
      <form action="<?php echo e(route('massages.update', ['id' =>$messages->id])); ?>" method="post" enctype="multipart/form-data">
          <?php echo e(csrf_field()); ?>

          <div class="form-group">
          <label for="name">name</label>
              <input type="text" name="name" class="form-control" value="<?php echo e($messages->name); ?>">
          
          </div>
       
          
           <div class="form-group">
          <label for="featured">Featured</label>
              <input type="file" name="featured" class="form-control">
              </div>
              <div class="form-group">
          <label for="name">price</label>
              <input type="number" name="price" class="form-control" value="<?php echo e($messages->price); ?>">
          
          </div>

          <div class="form-group">
          <label for="description">des</label>
              <textarea  name="description" cols="5" rows="5" class="form-control" value=""><?php echo e($messages->description); ?></textarea>
          
          </div>
          
          <div class="form-group">
          <div class="text-center">
              <button type="submit" class="btn btn-success">update product</button>
              
              </div>
          
          </div>
          </form>
      </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>