<form action="<?php echo e(route('cart.paypal',['id' =>$item->id])); ?>" method="post">
  <input type="hidden" name="cmd" value="_cart">
  <input type="hidden" name="upload" value="1">
  <input type="hidden" name="business" value="seller@designerfotos.com">

  <input type="hidden" name="item_name" value="<?php echo e($item->name); ?>">
  <input type="hidden" name="item_number" value="<?php echo e($item->price); ?>">
  <input type="hidden" name="qty" value="<?php echo e($item->qty); ?>">
  <input type="hidden" name="amount" value="<?php echo e($item->total()); ?>">

  <input type="image" name="submit"
    src="https://www.paypalobjects.com/en_US/i/btn/btn_buynow_LG.gif"
    alt="PayPal - The safer, easier way to pay online">
</form>