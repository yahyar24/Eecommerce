<?php if($paginator->hasPages()): ?>
    <nav class="navigation align-center">
     

        
        <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            

            
            <?php if(is_array($element)): ?>
                <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($page == $paginator->currentPage()): ?>
                        <a class="page-numbers bg-border-color current"><span><?php echo e($page); ?></span></a>

                    <?php else: ?>
                        
                        <a href="<?php echo e($url); ?>" class="page-numbers bg-border-color"><span><?php echo e($page); ?></span></a>

                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

       
    </nav>
<?php endif; ?>
