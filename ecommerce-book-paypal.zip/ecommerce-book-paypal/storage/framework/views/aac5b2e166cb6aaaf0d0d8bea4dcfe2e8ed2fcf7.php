<?php $__env->startSection('page'); ?>
<form action="<?php echo e(route('cart.paypal')); ?>" method="post">
  <input type="hidden" name="cmd" value="_cart">
  <input type="hidden" name="upload" value="1">
  <input type="hidden" name="business" value="seller@designerfotos.com">

  <input type="hidden" name="item_name" value="">
  <input type="hidden" name="item_number" value="">
  <input type="hidden" name="qty" value="">
  <input type="hidden" name="amount" value="">

  <input type="image" name="submit"
    src="https://www.paypalobjects.com/en_US/i/btn/btn_buynow_LG.gif"
    alt="PayPal - The safer, easier way to pay online">
</form>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>