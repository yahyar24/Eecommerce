<?php $__env->startSection('content'); ?>


<div class="panel panel-default">
    <div class="panel-body">
    
    <thead>
        <table width="400px"  class="table table-hover"> 
    
        <th>
          name
            
            </th>
             
            <th>
        
        price
        </th>
        
    <th>
        image
        </th>
          
        <th>
        
        edit
        </th>
        
        
        <th>
        
        delete
        </th>
        

        </thead>
        
        <tbody>
        
        <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <tr>
            
            <td>
                
                <?php echo e($message->name); ?>

                </td>
               
                 <td>
                
                <?php echo e($message->price); ?>

                </td>
                
                <td><img src="<?php echo e($message->featured); ?>"  width="90px" height="60px"></td>
                <td>
                            <a href="<?php echo e(route('massages.edit',['id' => $message->id])); ?>" class="btn btn-xs btn-info">Edite</a>
                        </td>
                <td>
                
                <a href="<?php echo e(route('massages.delete',['id' => $message->id])); ?>" class="btn btn-xs btn-danger">
                    delet
                    
                    </a>
                </td>

               
            </tr>
          
            
        
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
 </table>
               
    
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>