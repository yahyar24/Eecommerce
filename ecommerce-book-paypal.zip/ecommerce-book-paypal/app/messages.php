<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class messages extends Model
{
     protected $fillable= [
            'name', 'description','featured','price'
         ];
    
    public function getFeaturedAttribute($featured){
        
        return asset($featured);
    }
}
