<?php

namespace App\Http\Controllers;

use App\messages;
use Session;

use Illuminate\Http\Request;

class MassagesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('admin.massages.massages')->with('messages' , messages::all());
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
     return view('admin.massages.create');

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
         $this->validate($request,[
            
            'name' => 'required|max:255',
            'description' => 'required',
            'price' => 'required',
            'featured' => 'required|image',
            
            
        ]);
      

        $featured = $request->featured;

        $featured_new_name = time().$featured->getClientOriginalName();

        $featured->move('uploads/messages', $featured_new_name);

                
         $messages = messages::create([

            'name' =>$request->name,
            'price'=>$request->price,
          'description'  =>$request->description,
         'featured' => 'uploads/messages/'. $featured_new_name

             

        ]);
        Session::flash('success','created product successfuly');
        return redirect()->back();
        
        dd($request->all());
    }
    

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $messages =messages::find($id);

        return view('admin.massages.edit')->with('messages', $messages);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request,[
            'name' => 'required',
            'description' => 'required',
             'price' => 'required'
         ]);
            $messages = messages::find($id);
    
    
            if($request->hasFile('featured')){
    
                $featured = $request ->featured;
    
                $featured_new_name = time(). $featured->getClientOriginalName();
    
                $featured ->move('uploads/messages' , $featured_new_name);
    
                $messages ->featured =  'uploads/messages/' . $featured_new_name;
         }
    
        $messages->name = $request->name;
            $messages->description = $request->description;
            $messages->price =$request->price;
    
            $messages->save();
        
            Session::flash('success' , 'product updated successfully');
    
            return redirect()-> back();
        }
    

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $message= messages::find($id);
        
        $message->delete();
        
        return redirect()->back();
    }
}
