<?php

namespace App\Http\Controllers;
use Cart;
use App\messages;

use Illuminate\Http\Request;

class ShoppingController extends Controller
{
    public function add_to_cart(){

        
    }
    public function rapid_add($id){
        $pdt = messages::find($id);

        $CartItem= Cart::add([
             'id' =>$pdt->id,
             'name'=>$pdt->name,
             'qty' => 1,
             'price'=>$pdt->price,
         ]);
 
         Cart::associate($CartItem->rowId, 'App\messages');
 
         return redirect()->route('cart');
     }
     public function cart(){
         
         return view('cart');
 
 
     }
     public function cart_delete($id){
         Cart::remove($id);
 
         return redirect()->back();
 
     }
     public function incr($id,$qty)
     {
         Cart::update($id , $qty + 1);
 
         return redirect()->back();
 
     }
     public function decr($id,$qty)
     {
         Cart::update($id , $qty - 1);
 
         return redirect()->back();
 

    }
    
}
