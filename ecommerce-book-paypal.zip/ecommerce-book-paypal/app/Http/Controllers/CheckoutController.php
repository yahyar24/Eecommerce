<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Session;
use PayPal\Api\Amount;
use PayPal\Api\Item;
use PayPal\Api\ItemList;
use PayPal\Api\Payer;
use PayPal\Api\Transaction;
use PayPal\Api\Payment;
use PayPal\Api\Details;
use PayPal\Api\ChargeModel;
use PayPal\Api\Currency;
use PayPal\Api\MerchantPreferences;
use PayPal\Api\PaymentDefinition;
use PayPal\Api\Plan;
use PayPal\Api\Patch;
use PayPal\Api\PatchRequest;
use PayPal\Common\PayPalModel;
use PayPal\Rest\ApiContext;
use PayPal\Auth\OAuthTokenCredential;
use PayPal\Api\RedirectUrls;
use PayPal\Api\PaymentExecution;
use Cart;
use Illuminate\Http\Request;

use URL;
use Redirect;
use Illuminate\Support\Facades\Input;


class CheckoutController extends Controller
{
    public function index(){
        return view('checkout');
    }
    public function __construct()
    {
            /** PayPal api context **/
            $settings  = config('paypal.settings');
            $client_id = config('paypal.client_id');
            $secret    = config('paypal.secret');
            $this->_api_context = new ApiContext(new OAuthTokenCredential(
               $client_id,
               $secret)
            );
           
    }
    public function pay(){

        //dd(request()->all());
        $payer = New Payer();
        $payer->setPaymentMethod('paypal');
        
        $counter = 0;
        
        foreach(Input::all() as $input){
            $item = New Item();
            $item->setName(Input::get('name'.$counter))
                ->setCurrency('EUR')
                ->setQuantity(Input::get('qty'.$counter))
                 ->setPrice(Input::get('price'.$counter));
                 
                 $counter ++;

               

        }
                
    }
    
}
