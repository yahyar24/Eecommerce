@extends('layouts.app')


@section('content')

@include('admin.includes.errors')
<div class="panel panel-default">
      
      <div class="panel-heading">
      
      create product
      </div>
      
      <div class="panel-body">
      
      <form action="{{route('massages.store')}}" method="post" enctype="multipart/form-data">
          {{csrf_field()}}
          <div class="form-group">
          <label for="name">name</label>
              <input type="text" name="name" class="form-control">
          
          </div>
       
          
           <div class="form-group">
          <label for="featured">Featured</label>
              <input type="file" name="featured" class="form-control">
              </div>
              <div class="form-group">
          <label for="name">price</label>
              <input type="number" name="price" class="form-control">
          
          </div>

          <div class="form-group">
          <label for="message">des</label>
              <textarea  name="description" cols="5" rows="5" class="form-control"></textarea>
          
          </div>
          
          <div class="form-group">
          <div class="text-center">
              <button type="submit" class="btn btn-success">save product</button>
              
              </div>
          
          </div>
          </form>
      </div>
</div>

@stop