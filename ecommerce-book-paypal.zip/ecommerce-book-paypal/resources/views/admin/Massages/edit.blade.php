@extends('layouts.app')


@section('content')

@include('admin.includes.errors')
<div class="panel panel-default">
      
      <div class="panel-heading">
      
      update product
      </div>
      
      <div class="panel-body">
      
      <form action="{{route('massages.update', ['id' =>$messages->id])}}" method="post" enctype="multipart/form-data">
          {{csrf_field()}}
          <div class="form-group">
          <label for="name">name</label>
              <input type="text" name="name" class="form-control" value="{{$messages->name}}">
          
          </div>
       
          
           <div class="form-group">
          <label for="featured">Featured</label>
              <input type="file" name="featured" class="form-control">
              </div>
              <div class="form-group">
          <label for="name">price</label>
              <input type="number" name="price" class="form-control" value="{{$messages->price}}">
          
          </div>

          <div class="form-group">
          <label for="description">des</label>
              <textarea  name="description" cols="5" rows="5" class="form-control" value="">{{$messages->description}}</textarea>
          
          </div>
          
          <div class="form-group">
          <div class="text-center">
              <button type="submit" class="btn btn-success">update product</button>
              
              </div>
          
          </div>
          </form>
      </div>
</div>

@stop