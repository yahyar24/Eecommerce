@extends('layouts.app')


@section('content')


<div class="panel panel-default">
    <div class="panel-body">
    
    <thead>
        <table width="400px"  class="table table-hover"> 
    
        <th>
          name
            
            </th>
             
            <th>
        
        price
        </th>
        
    <th>
        image
        </th>
          
        <th>
        
        edit
        </th>
        
        
        <th>
        
        delete
        </th>
        

        </thead>
        
        <tbody>
        
        @foreach($messages as $message)
            
            <tr>
            
            <td>
                
                {{$message->name}}
                </td>
               
                 <td>
                
                {{$message->price}}
                </td>
                
                <td><img src="{{$message->featured}}"  width="90px" height="60px"></td>
                <td>
                            <a href="{{route('massages.edit',['id' => $message->id])}}" class="btn btn-xs btn-info">Edite</a>
                        </td>
                <td>
                
                <a href="{{route('massages.delete',['id' => $message->id])}}" class="btn btn-xs btn-danger">
                    delet
                    
                    </a>
                </td>

               
            </tr>
          
            
        
            
            @endforeach
        </tbody>
 </table>
               
    
    </div>
</div>

@stop
